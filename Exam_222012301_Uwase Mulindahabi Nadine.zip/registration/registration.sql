-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2024 at 11:33 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Name` varchar(50) NOT NULL,
  `User_Name` varchar(50) NOT NULL,
  `ID` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Name`, `User_Name`, `ID`, `Email`, `Phone`, `Password`) VALUES
('', '', '', '', '', ''),
('MURINDAHABI', 'NADINE', '122', 'NADINE@GMAIL.COM', '078996778', '123123'),
('linker', 'lili', '2345666', 'lili@gmail.com', '328764987328', '123'),
('Uwase', 'Keza', '2201', 'nadiuwase2@gmail.com', '078893', '123123'),
('Shebah', 'cluella', '223', 'shebah@', '0899', '123'),
('lando', 'Naho', '2201', 'nah@gmail.com', '078875', '123'),
('Nadine', 'Uwase', '3333', 'na@gmail.com', '97888', '222012301'),
('Nadine', 'Uwase', '22203', 'nadiuwase@gmail.com', '0788', '222012301'),
('Nadine', 'Uwase', '2229', 'nad@gmail.com', '4937', '222012301'),
('UWASE', 'Nadine', '234422', 'n@GMAIL.COM', '27876', '222012301');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
